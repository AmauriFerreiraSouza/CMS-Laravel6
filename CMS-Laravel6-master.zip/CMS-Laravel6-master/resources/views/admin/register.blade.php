@extends('adminlte::register')<!--extendo da minha biblioteca adminLTE a tela de cadastro-->

@section('title', 'cadastro')<!--coloco um titulo na minha aba-->