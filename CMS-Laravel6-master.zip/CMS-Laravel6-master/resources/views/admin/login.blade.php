@extends('adminlte::login')<!--extendo da minha biblioteca adminLTE a tela de login-->

@section('title', 'login')<!--coloco um titulo na minha aba-->